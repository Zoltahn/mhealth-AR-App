# mhealth-AR-App

This repository is for the code to implement the android mobile application.
Currently the mobile appication features a display of the mobile accelerometer data.
